const choices = ["rock", "paper", "scissors"];
const buttons = document.querySelectorAll('.choice');
const playerChoiceText = document.getElementById('player-choice');
const computerChoiceText = document.getElementById('computer-choice');
const winnerText = document.getElementById('winner');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const playerChoice = button.id;
    const computerChoice = choices[Math.floor(Math.random() * choices.length)];
    const result = determineWinner(playerChoice, computerChoice);

    playerChoiceText.textContent = `Player chose: ${playerChoice}`;
    computerChoiceText.textContent = `Computer chose: ${computerChoice}`;
    winnerText.textContent = `Result: ${result}`;
  });
});

function determineWinner(player, computer) {
  if (player === computer) {
    return "It's a tie!";
  } else if ((player === "rock" && computer === "scissors") ||
             (player === "paper" && computer === "rock") ||
             (player === "scissors" && computer === "paper")) {
    return "Player wins!";
  } else {
    return "Computer wins!";
  }
}
